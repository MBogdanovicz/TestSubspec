//
//  A2BCore.h
//  A2BCore
//
//  Created by Marcelo Bogdanovicz on 22/02/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for A2BCore.
FOUNDATION_EXPORT double A2BCoreVersionNumber;

//! Project version string for A2BCore.
FOUNDATION_EXPORT const unsigned char A2BCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A2BCore/PublicHeader.h>


